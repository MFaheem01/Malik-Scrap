import express, { Request, Response } from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import AdmZip from 'adm-zip';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

app.use(express.json());

// Persistent Data Storage Path
const DATA_DIR = path.join(__dirname, 'data');
const DB_FILE = path.join(DATA_DIR, 'db.json');

// Ensure data directory exists
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

// Initial Seed Data
const initialData = {
  admin: {
    username: 'admin',
    password: 'password123', // In production or demo, can be updated via dashboard
  },
  contact: {
    companyName: 'FerroMax Scrap Metal & Recycling',
    tagline: 'Premier Industrial Scrap Metal Recycling & Container Dispatch',
    phone: '+1 (800) 555-7272',
    dispatchPhone: '+1 (800) 555-SCRAP',
    email: 'dispatch@ferromaxmetals.com',
    secondaryEmail: 'quotes@ferromaxmetals.com',
    address: '4820 Industrial Parkway, Dock #4',
    city: 'Detroit',
    state: 'MI',
    zip: '48210',
    country: 'United States',
    hoursWeekday: 'Monday - Friday: 6:30 AM - 5:30 PM',
    hoursSaturday: 'Saturday: 7:00 AM - 2:00 PM',
    hoursSunday: 'Sunday: Closed (Emergency Dispatch On-Call)',
    googleMapsUrl: 'https://maps.google.com/?q=4820+Industrial+Parkway+Detroit+MI+48210',
    emergencyHotline: '24/7 Roll-Off & Commercial Container Dispatch Available',
    social: {
      facebook: 'https://facebook.com',
      twitter: 'https://x.com',
      linkedin: 'https://linkedin.com',
      youtube: 'https://youtube.com',
    },
  },
  services: [
    {
      id: 'srv-1',
      title: 'Ferrous Metals Recycling',
      category: 'Ferrous',
      shortDesc: 'Complete processing of heavy melting steel (HMS 1&2), structural I-beams, plate & structural, cast iron, and shredded auto steel.',
      description: 'Our heavy-duty hydraulic shears and high-capacity shredders process over 10,000 tons of structural steel, industrial machinery, and demolition rebar every month. Certified NTEP truck scales guarantee accurate net tonnage with instant settlement.',
      icon: 'Hammer',
      image: '/src/assets/images/ferrous_steel_recycling_1793892530649.jpg',
      badge: 'High Volume',
      highlight: 'Direct mill pricing with zero intermediary deductions.',
    },
    {
      id: 'srv-2',
      title: 'Non-Ferrous & Copper Reclamation',
      category: 'Non-Ferrous',
      shortDesc: 'Top-dollar valuation for Bare Bright copper wire, #1 & #2 copper tubing, yellow brass, red brass, aluminum extrusion, and lead.',
      description: 'We utilize handheld XRF alloy spectrometers for instant, non-destructive elemental analysis. Get maximum payout for high-grade insulated electrical cable, copper bus bars, radiators, and brass plumbing components.',
      icon: 'Zap',
      image: '/src/assets/images/copper_wire_brass_1793892530421.jpg',
      badge: 'Top Payout',
      highlight: 'Immediate cash, company check, or same-day wire transfer.',
    },
    {
      id: 'srv-3',
      title: 'Commercial Roll-Off Container Fleet',
      category: 'Commercial Logistics',
      shortDesc: 'Custom placement of 10, 20, 30, and 40-yard heavy-gauge steel scrap dumpsters delivered to your fabrication plant or demolition site.',
      description: 'Streamline your facility scrap management. We deliver heavy-duty roll-off containers within 24 hours. When full, call or tap to dispatch a swap—we weigh on certified truck scales and generate transparent weight tickets.',
      icon: 'Truck',
      image: '/src/assets/images/industrial_scrap_containers_1793892531220.jpg',
      badge: '24h Dispatch',
      highlight: 'Complimentary drop-off and flexible pickup schedules.',
    },
    {
      id: 'srv-4',
      title: 'Demolition & Plant Decommissioning',
      category: 'Industrial Service',
      shortDesc: 'On-site industrial shearing, torch cutting, structural steel dismantle, and site clearance for manufacturing and commercial facilities.',
      description: 'Our licensed, OSHA-certified dismantling crews manage turnkey plant clearing. We bring mobile shear excavators, crane grapples, and torch specialists to dismantle silos, stamping presses, overhead cranes, and mechanical plants.',
      icon: 'Wrench',
      image: '/src/assets/images/hero_scrap_facility_1793892530533.jpg',
      badge: 'Turnkey Crews',
      highlight: 'Comprehensive environmental compliance and safety bonding.',
    },
    {
      id: 'srv-5',
      title: 'Catalytic Converters & Auto Scrap',
      category: 'Automotive',
      shortDesc: 'Precision valuation of OEM automotive catalytic converters, auto bodies, transmissions, engines, and aluminum wheels.',
      description: 'We grade catalytic converters based on real-time platinum, palladium, and rhodium market assays. Auto wreckers and collision centers receive premium bulk pricing with certified depollution and recycling compliance.',
      icon: 'Car',
      image: '/src/assets/images/ferrous_steel_recycling_1793892530649.jpg',
      badge: 'Lab Assay',
      highlight: 'Serialized inventory tracking with instant assay verification.',
    },
    {
      id: 'srv-6',
      title: 'Specialty Alloys & E-Scrap',
      category: 'Exotic Alloys',
      shortDesc: 'Reclamation of aerospace alloys including Inconel, Hastelloy, Monel, Titanium, 316 Stainless Steel, and electronic circuit boards.',
      description: 'Certified recovery for high-value industrial manufacturing turnings, aerospace solid drops, carbide tooling, and commercial printed circuit boards. We guarantee strict metal segregation and metallurgical certification.',
      icon: 'Cpu',
      image: '/src/assets/images/copper_wire_brass_1793892530421.jpg',
      badge: 'High Value',
      highlight: 'XRF certified analysis with certified destruction documents.',
    },
  ],
  blogs: [
    {
      id: 'blog-1',
      title: '2026 Scrap Metal Market Outlook: Copper & Aluminum Price Trends',
      slug: '2026-scrap-metal-market-outlook',
      excerpt: 'Global infrastructure demand and green energy electrification continue to push copper prices higher. Here is what industrial facilities should anticipate.',
      content: 'The industrial scrap metal market has entered an unprecedented cycle of demand driven by electrification, renewable power grids, and domestic manufacturing reshoring. Bare bright copper wire and clean copper tubing command high premiums. In this article, our chief metallurgist breaks down the key macroeconomic factors influencing COMEX and LME pricing, and how metal fabricators can optimize their scrap separation to capture peak market rates.',
      author: 'Marcus Vance, Chief Metallurgist',
      date: 'October 24, 2026',
      commentsCount: 14,
      image: '/src/assets/images/copper_wire_brass_1793892530421.jpg',
      category: 'Market Trends',
    },
    {
      id: 'blog-2',
      title: 'How Manufacturing Facilities Maximize Revenue on Machine Shop Scrap',
      slug: 'maximize-revenue-machine-shop-scrap',
      excerpt: 'Unsegregated chips and turnings can cost your shop up to 40% in scrap deductions. Learn our 4-step sorting protocol.',
      content: 'For machine shops and CNC fabrication plants, scrap metal is not just waste—it is a critical revenue center. Mixing stainless steel chips with mild carbon steel degrades the batch value to generic shredder pricing. By implementing color-coded roll-off bins, centrifugal de-oiling, and strict alloy identification at each CNC work center, facilities can increase scrap yields by thousands of dollars each month.',
      author: 'Elena Rostova, VP of Logistics',
      date: 'September 18, 2026',
      commentsCount: 22,
      image: '/src/assets/images/industrial_scrap_containers_1793892531220.jpg',
      category: 'Operations',
    },
    {
      id: 'blog-3',
      title: 'Ferrous vs. Non-Ferrous: Complete Identification & Sorting Guide',
      slug: 'ferrous-vs-non-ferrous-sorting-guide',
      excerpt: 'The magnet test is only step one. Discover advanced spark testing, weight density, and oxidation signs to accurately grade scrap.',
      content: 'Sorting metals properly is the single most lucrative habit in scrap recycling. While ferrous metals contain iron and adhere to a neodymium magnet, non-ferrous metals like aluminum, copper, brass, and titanium resist magnetism and offer higher per-pound payouts. In this comprehensive guide, we walk through practical yard tests, handling procedures, and safety tips for commercial contractors.',
      author: 'David Chen, Yard Master',
      date: 'August 12, 2026',
      commentsCount: 31,
      image: '/src/assets/images/ferrous_steel_recycling_1793892530649.jpg',
      category: 'Recycling Guide',
    },
  ],
  prices: [
    { metal: 'Bare Bright Copper Wire', price: '$4.15', unit: 'per lb', trend: 'up', change: '+0.12' },
    { metal: '#1 Copper Tubing', price: '$3.92', unit: 'per lb', trend: 'up', change: '+0.08' },
    { metal: '#2 Clean Copper', price: '$3.60', unit: 'per lb', trend: 'stable', change: '0.00' },
    { metal: 'Yellow Brass Solids', price: '$2.45', unit: 'per lb', trend: 'up', change: '+0.05' },
    { metal: 'Clean Aluminum Extrusion', price: '$0.88', unit: 'per lb', trend: 'down', change: '-0.02' },
    { metal: '304 Stainless Steel Scrap', price: '$0.68', unit: 'per lb', trend: 'stable', change: '0.00' },
    { metal: 'HMS 1 Heavy Melting Steel', price: '$365.00', unit: 'per ton', trend: 'up', change: '+15.00' },
    { metal: 'Unprepared Steel Scrap', price: '$290.00', unit: 'per ton', trend: 'stable', change: '0.00' },
  ],
  consultations: [
    {
      id: 'lead-1',
      name: 'Robert Miller',
      email: 'rmiller@greatlakesmfg.com',
      phone: '+1 (313) 555-0192',
      subject: 'Monthly Roll-Off Bin Service for 40-man CNC Shop',
      message: 'We generate approximately 8,000 lbs of 6061 aluminum turnings and 3,000 lbs of stainless steel weekly. Looking for a dedicated 30-yard container with bi-weekly rotation.',
      date: '2026-11-04 14:20',
      status: 'In Progress',
    },
    {
      id: 'lead-2',
      name: 'Sarah Jenkins',
      email: 'sjenkins@apexconstruct.org',
      phone: '+1 (248) 555-8831',
      subject: 'Warehouse Demolition Structural Steel Salvage',
      message: 'Demolishing a 45,000 sq ft industrial warehouse in January. Seeking quote for on-site torch shearing and scrap removal of heavy I-beams and corrugated steel decking.',
      date: '2026-11-03 09:45',
      status: 'New',
    },
  ],
};

// Initialize DB if not exists
function readDb() {
  try {
    if (!fs.existsSync(DB_FILE)) {
      fs.writeFileSync(DB_FILE, JSON.stringify(initialData, null, 2), 'utf-8');
      return initialData;
    }
    const raw = fs.readFileSync(DB_FILE, 'utf-8');
    return JSON.parse(raw);
  } catch (err) {
    console.error('Error reading db.json, returning default data:', err);
    return initialData;
  }
}

function writeDb(data: typeof initialData) {
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), 'utf-8');
    return true;
  } catch (err) {
    console.error('Error writing to db.json:', err);
    return false;
  }
}

// ----------------- API ROUTES ----------------- //

// 1. Auth & Admin Credentials
app.post('/api/auth/login', (req: Request, res: Response) => {
  const { username, password } = req.body;
  const db = readDb();
  if (username === db.admin.username && password === db.admin.password) {
    return res.json({
      success: true,
      token: 'ferromax-session-' + Date.now(),
      username: db.admin.username,
    });
  }
  return res.status(401).json({ success: false, message: 'Invalid admin username or password' });
});

app.post('/api/auth/update-credentials', (req: Request, res: Response) => {
  const { currentPassword, newUsername, newPassword } = req.body;
  const db = readDb();
  if (currentPassword !== db.admin.password) {
    return res.status(401).json({ success: false, message: 'Current password does not match' });
  }
  if (newUsername) {
    db.admin.username = newUsername.trim();
  }
  if (newPassword && newPassword.trim().length >= 6) {
    db.admin.password = newPassword.trim();
  } else if (newPassword) {
    return res.status(400).json({ success: false, message: 'New password must be at least 6 characters' });
  }
  writeDb(db);
  return res.json({ success: true, message: 'Credentials updated successfully', username: db.admin.username });
});

// 2. Contact & Location
app.get('/api/contact', (_req: Request, res: Response) => {
  const db = readDb();
  res.json(db.contact);
});

app.put('/api/contact', (req: Request, res: Response) => {
  const db = readDb();
  db.contact = { ...db.contact, ...req.body };
  writeDb(db);
  res.json({ success: true, contact: db.contact });
});

// 3. Services Management
app.get('/api/services', (_req: Request, res: Response) => {
  const db = readDb();
  res.json(db.services);
});

app.post('/api/services', (req: Request, res: Response) => {
  const db = readDb();
  const newService = {
    id: 'srv-' + Date.now(),
    title: req.body.title || 'Untitled Service',
    category: req.body.category || 'General',
    shortDesc: req.body.shortDesc || '',
    description: req.body.description || '',
    icon: req.body.icon || 'Hammer',
    image: req.body.image || '/src/assets/images/ferrous_steel_recycling_1793892530649.jpg',
    badge: req.body.badge || 'New',
    highlight: req.body.highlight || '',
  };
  db.services.push(newService);
  writeDb(db);
  res.status(201).json(newService);
});

app.put('/api/services/:id', (req: Request, res: Response) => {
  const { id } = req.params;
  const db = readDb();
  const index = db.services.findIndex((s: any) => s.id === id);
  if (index === -1) {
    return res.status(404).json({ error: 'Service not found' });
  }
  db.services[index] = { ...db.services[index], ...req.body, id };
  writeDb(db);
  res.json(db.services[index]);
});

app.delete('/api/services/:id', (req: Request, res: Response) => {
  const { id } = req.params;
  const db = readDb();
  db.services = db.services.filter((s: any) => s.id !== id);
  writeDb(db);
  res.json({ success: true });
});

// 4. Blogs Management
app.get('/api/blogs', (_req: Request, res: Response) => {
  const db = readDb();
  res.json(db.blogs);
});

app.post('/api/blogs', (req: Request, res: Response) => {
  const db = readDb();
  const newBlog = {
    id: 'blog-' + Date.now(),
    title: req.body.title || 'Untitled Article',
    slug: (req.body.title || 'article').toLowerCase().replace(/[^a-z0-9]+/g, '-'),
    excerpt: req.body.excerpt || '',
    content: req.body.content || '',
    author: req.body.author || 'Admin',
    date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
    commentsCount: 0,
    image: req.body.image || '/src/assets/images/copper_wire_brass_1793892530421.jpg',
    category: req.body.category || 'Industry News',
  };
  db.blogs.unshift(newBlog);
  writeDb(db);
  res.status(201).json(newBlog);
});

app.put('/api/blogs/:id', (req: Request, res: Response) => {
  const { id } = req.params;
  const db = readDb();
  const index = db.blogs.findIndex((b: any) => b.id === id);
  if (index === -1) {
    return res.status(404).json({ error: 'Blog not found' });
  }
  db.blogs[index] = { ...db.blogs[index], ...req.body, id };
  writeDb(db);
  res.json(db.blogs[index]);
});

app.delete('/api/blogs/:id', (req: Request, res: Response) => {
  const { id } = req.params;
  const db = readDb();
  db.blogs = db.blogs.filter((b: any) => b.id !== id);
  writeDb(db);
  res.json({ success: true });
});

// 5. Scrap Prices
app.get('/api/prices', (_req: Request, res: Response) => {
  const db = readDb();
  res.json(db.prices);
});

app.put('/api/prices', (req: Request, res: Response) => {
  const db = readDb();
  if (Array.isArray(req.body)) {
    db.prices = req.body;
    writeDb(db);
    return res.json({ success: true, prices: db.prices });
  }
  res.status(400).json({ error: 'Expected array of prices' });
});

// 6. Consultations / Lead Quotes Capture
app.get('/api/consultations', (_req: Request, res: Response) => {
  const db = readDb();
  res.json(db.consultations || []);
});

app.post('/api/consultations', (req: Request, res: Response) => {
  const { name, email, phone, subject, message } = req.body;
  if (!name || !email) {
    return res.status(400).json({ error: 'Name and email are required' });
  }
  const db = readDb();
  const newLead = {
    id: 'lead-' + Date.now(),
    name,
    email,
    phone: phone || '',
    subject: subject || 'General Scrap Metal Inquiry',
    message: message || '',
    date: new Date().toISOString().replace('T', ' ').substring(0, 16),
    status: 'New',
  };
  if (!db.consultations) db.consultations = [];
  db.consultations.unshift(newLead);
  writeDb(db);
  res.status(201).json({ success: true, lead: newLead });
});

app.put('/api/consultations/:id', (req: Request, res: Response) => {
  const { id } = req.params;
  const { status } = req.body;
  const db = readDb();
  const lead = (db.consultations || []).find((c: any) => c.id === id);
  if (!lead) return res.status(404).json({ error: 'Lead not found' });
  lead.status = status;
  writeDb(db);
  res.json({ success: true, lead });
});

// 7. Full Project ZIP Export
app.get('/api/download-zip', (_req: Request, res: Response) => {
  try {
    const zip = new AdmZip();
    const rootDir = __dirname;

    // Files and folders to include
    const filesToInclude = [
      'index.html',
      'package.json',
      'tsconfig.json',
      'vite.config.ts',
      'metadata.json',
      '.env.example',
      '.gitignore',
      'server.ts',
    ];

    filesToInclude.forEach((file) => {
      const fullPath = path.join(rootDir, file);
      if (fs.existsSync(fullPath)) {
        zip.addLocalFile(fullPath);
      }
    });

    const dirsToInclude = ['src', 'public', 'data'];
    dirsToInclude.forEach((dir) => {
      const fullPath = path.join(rootDir, dir);
      if (fs.existsSync(fullPath)) {
        zip.addLocalFolder(fullPath, dir);
      }
    });

    const buffer = zip.toBuffer();
    res.set({
      'Content-Type': 'application/zip',
      'Content-Disposition': 'attachment; filename="ferromax-scrap-metal-project.zip"',
      'Content-Length': buffer.length,
    });
    res.send(buffer);
  } catch (err) {
    console.error('Error generating project ZIP:', err);
    res.status(500).json({ error: 'Failed to generate ZIP archive' });
  }
});

// ----------------- VITE MIDDLEWARE / STATIC FILES ----------------- //
async function startServer() {
  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.join(__dirname, 'dist', 'index.html'));
    });
  } else {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running at http://0.0.0.0:${PORT}`);
  });
}

startServer();
