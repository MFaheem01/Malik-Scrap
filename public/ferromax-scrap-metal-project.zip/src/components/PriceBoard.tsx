import React, { useState } from 'react';
import { TrendingUp, TrendingDown, Minus, Calculator, ArrowRight, ShieldCheck, RefreshCw } from 'lucide-react';
import { ScrapPrice } from '../types';

interface PriceBoardProps {
  prices: ScrapPrice[];
  onQuoteWithEstimate: (metal: string, weight: string, estimatedTotal: string) => void;
}

export const PriceBoard: React.FC<PriceBoardProps> = ({ prices, onQuoteWithEstimate }) => {
  const [selectedMetal, setSelectedMetal] = useState<string>(prices[0]?.metal || 'Bare Bright Copper Wire');
  const [weightInput, setWeightInput] = useState<string>('500');

  // Compute calculated total
  const currentItem = prices.find((p) => p.metal === selectedMetal) || prices[0];
  const unitRate = currentItem ? parseFloat(currentItem.price.replace(/[^0-9.]/g, '')) : 0;
  const numericWeight = parseFloat(weightInput) || 0;
  const estimatedTotal = (unitRate * numericWeight).toFixed(2);

  return (
    <section id="prices" className="py-20 lg:py-24 bg-white relative border-b border-slate-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-14">
          <span className="text-sm font-bold text-orange-600 uppercase tracking-wider block mb-2">
            Market Rates & Valuation
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight mb-4">
            Today's Scrap Metal Prices
          </h2>
          <p className="text-slate-600 text-sm sm:text-base leading-relaxed">
            Direct mill and COMEX-indexed benchmark pricing updated daily. Volume bonuses available for
            industrial accounts producing 5,000+ lbs monthly.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left Table: Live Scrap Rates */}
          <div className="lg:col-span-7 bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="p-4 sm:p-5 bg-slate-900 text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
                <span className="font-bold text-sm sm:text-base">Live Mill Benchmark Tickers</span>
              </div>
              <span className="text-xs text-slate-400">Updated: Today 08:00 EST</span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-sm">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 text-xs font-semibold uppercase tracking-wider">
                    <th className="py-3 px-4">Material Grade</th>
                    <th className="py-3 px-4">Current Rate</th>
                    <th className="py-3 px-4">Unit</th>
                    <th className="py-3 px-4 text-right">Day Trend</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {prices.map((item) => (
                    <tr
                      key={item.metal}
                      onClick={() => setSelectedMetal(item.metal)}
                      className={`hover:bg-orange-50/60 transition-colors cursor-pointer ${
                        selectedMetal === item.metal ? 'bg-orange-50/90 font-medium' : ''
                      }`}
                    >
                      <td className="py-3 px-4 text-slate-900 flex items-center gap-2">
                        {selectedMetal === item.metal && (
                          <span className="w-1.5 h-1.5 rounded-full bg-orange-600" />
                        )}
                        <span>{item.metal}</span>
                      </td>
                      <td className="py-3 px-4 font-bold text-slate-900 tabular-nums">
                        {item.price}
                      </td>
                      <td className="py-3 px-4 text-slate-500 text-xs">
                        {item.unit}
                      </td>
                      <td className="py-3 px-4 text-right">
                        <span
                          className={`inline-flex items-center gap-1 text-xs font-semibold tabular-nums ${
                            item.trend === 'up'
                              ? 'text-emerald-600'
                              : item.trend === 'down'
                              ? 'text-red-600'
                              : 'text-slate-500'
                          }`}
                        >
                          {item.trend === 'up' && <TrendingUp className="w-3.5 h-3.5" />}
                          {item.trend === 'down' && <TrendingDown className="w-3.5 h-3.5" />}
                          {item.trend === 'stable' && <Minus className="w-3.5 h-3.5" />}
                          <span>{item.change}</span>
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="p-3 bg-slate-50 border-t border-slate-200 text-[11px] text-slate-500 flex items-center justify-between">
              <span>* Pricing subject to certified scale assay and clean scrap segregation.</span>
              <span className="font-semibold text-slate-700">Click any row to calculate value</span>
            </div>
          </div>

          {/* Right: Instant Scrap Value Estimator Calculator */}
          <div className="lg:col-span-5 bg-[#0b1329] text-white rounded-xl shadow-xl border border-slate-800 p-6 sm:p-8 flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-2.5 text-orange-500 mb-2">
                <Calculator className="w-5 h-5" />
                <span className="text-xs font-bold uppercase tracking-wider">Instant Estimator</span>
              </div>
              <h3 className="text-xl font-bold text-white mb-2">
                Calculate Your Scrap Metal Value
              </h3>
              <p className="text-xs text-slate-300 leading-relaxed mb-6">
                Estimate the return on your industrial drops, copper wire, or roll-off bin loads.
              </p>

              <div className="space-y-4">
                {/* Material Select */}
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1.5">
                    Select Material Grade
                  </label>
                  <select
                    value={selectedMetal}
                    onChange={(e) => setSelectedMetal(e.target.value)}
                    className="w-full bg-[#070d1e] text-white text-sm px-3.5 py-2.5 rounded border border-slate-700 focus:outline-none focus:border-orange-500 transition-colors"
                  >
                    {prices.map((p) => (
                      <option key={p.metal} value={p.metal}>
                        {p.metal} — ({p.price} {p.unit})
                      </option>
                    ))}
                  </select>
                </div>

                {/* Weight Input */}
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1.5">
                    Estimated Weight ({currentItem?.unit || 'lbs/tons'})
                  </label>
                  <div className="relative">
                    <input
                      type="number"
                      min="1"
                      value={weightInput}
                      onChange={(e) => setWeightInput(e.target.value)}
                      className="w-full bg-[#070d1e] text-white text-sm px-3.5 py-2.5 rounded border border-slate-700 focus:outline-none focus:border-orange-500 transition-colors tabular-nums"
                      placeholder="e.g. 500"
                    />
                    <span className="absolute right-3.5 top-2.5 text-xs text-slate-400">
                      {currentItem?.unit}
                    </span>
                  </div>
                </div>

                {/* Calculation Output Box */}
                <div className="p-4 rounded-lg bg-orange-950/40 border border-orange-500/30 my-4 text-center">
                  <span className="text-xs text-orange-300 uppercase tracking-wider block font-semibold">
                    Estimated Payout Value
                  </span>
                  <div className="text-3xl sm:text-4xl font-extrabold text-orange-400 my-1 tabular-nums">
                    ${Number(estimatedTotal).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </div>
                  <span className="text-[11px] text-slate-400">
                    Based on {weightInput} {currentItem?.unit} @ {currentItem?.price}
                  </span>
                </div>
              </div>
            </div>

            <div className="pt-4 mt-4 border-t border-slate-800">
              <button
                onClick={() => onQuoteWithEstimate(selectedMetal, weightInput, estimatedTotal)}
                className="w-full bg-orange-600 hover:bg-orange-700 active:bg-orange-800 text-white font-semibold text-sm py-3 px-4 rounded transition-all shadow-md shadow-orange-600/30 flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>Lock In Rate & Request Pickup</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <div className="mt-3 flex items-center justify-center gap-2 text-[11px] text-slate-400">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                <span>Zero obligation · Free container drop-off on qualifying loads</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
