import React from 'react';
import { MapPin, Navigation, Clock, Scale, Truck, Phone, CheckCircle, ExternalLink } from 'lucide-react';
import { ContactInfo } from '../types';

interface LocationSectionProps {
  contact: ContactInfo;
  onRequestDropoff: () => void;
}

export const LocationSection: React.FC<LocationSectionProps> = ({ contact, onRequestDropoff }) => {
  return (
    <section id="location" className="py-20 lg:py-24 bg-slate-900 text-white relative overflow-hidden">
      {/* Decorative accent */}
      <div className="absolute top-0 left-0 right-0 h-1 bg-orange-600" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-14">
          <span className="text-sm font-bold text-orange-500 uppercase tracking-wider block mb-2">
            Facility & Weighbridge
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight mb-4">
            Visit Our Main Recycling Yard
          </h2>
          <p className="text-slate-300 text-sm sm:text-base leading-relaxed">
            Convenient heavy-haul access located off the industrial expressway. Equipped with dual 70-foot
            NTEP-certified digital truck platform scales for rapid entry and zero waiting.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          {/* Facility Details Column */}
          <div className="lg:col-span-5 bg-slate-950/80 rounded-xl border border-slate-800 p-6 sm:p-8 flex flex-col justify-between shadow-2xl">
            <div className="space-y-6">
              {/* Address card */}
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-lg bg-orange-600/20 border border-orange-500/40 text-orange-500 flex items-center justify-center shrink-0">
                  <MapPin className="w-6 h-6" />
                </div>
                <div>
                  <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block">
                    Yard Location & Scale Entrance
                  </span>
                  <h3 className="text-lg font-bold text-white mt-0.5">
                    {contact.address}
                  </h3>
                  <p className="text-slate-300 text-sm">
                    {contact.city}, {contact.state} {contact.zip}, {contact.country}
                  </p>
                  <p className="text-xs text-orange-400 mt-1 font-medium">
                    Commercial Trucks: Enter via North Industrial Gate 2
                  </p>
                </div>
              </div>

              {/* Operating Hours */}
              <div className="flex items-start gap-4 border-t border-slate-800/80 pt-5">
                <div className="w-12 h-12 rounded-lg bg-blue-600/20 border border-blue-500/40 text-blue-400 flex items-center justify-center shrink-0">
                  <Clock className="w-6 h-6" />
                </div>
                <div>
                  <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block">
                    Public Scale & Receiving Hours
                  </span>
                  <div className="mt-1 space-y-1 text-sm text-slate-200">
                    <p className="flex justify-between gap-4">
                      <span className="text-slate-400">Weekdays:</span>
                      <span className="font-semibold">{contact.hoursWeekday.replace('Monday - Friday: ', '')}</span>
                    </p>
                    <p className="flex justify-between gap-4">
                      <span className="text-slate-400">Saturday:</span>
                      <span className="font-semibold">{contact.hoursSaturday.replace('Saturday: ', '')}</span>
                    </p>
                    <p className="flex justify-between gap-4 text-orange-400 text-xs">
                      <span className="text-slate-400">Sunday:</span>
                      <span>{contact.hoursSunday.replace('Sunday: ', '')}</span>
                    </p>
                  </div>
                </div>
              </div>

              {/* Facility Capabilities */}
              <div className="flex items-start gap-4 border-t border-slate-800/80 pt-5">
                <div className="w-12 h-12 rounded-lg bg-emerald-600/20 border border-emerald-500/40 text-emerald-400 flex items-center justify-center shrink-0">
                  <Scale className="w-6 h-6" />
                </div>
                <div>
                  <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block">
                    Scale Specifications
                  </span>
                  <div className="mt-1 space-y-1 text-xs text-slate-300">
                    <p className="flex items-center gap-1.5">
                      <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Dual 120,000 lb capacity electronic truck scales</span>
                    </p>
                    <p className="flex items-center gap-1.5">
                      <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Dedicated non-ferrous drive-thru indoor warehouse</span>
                    </p>
                    <p className="flex items-center gap-1.5">
                      <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Direct railroad siding for bulk rail car scrap dispatch</span>
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Buttons */}
            <div className="pt-6 border-t border-slate-800 flex flex-col sm:flex-row gap-3 mt-6">
              <a
                href={contact.googleMapsUrl || `https://maps.google.com/?q=${encodeURIComponent(contact.address + ' ' + contact.city + ' ' + contact.state)}`}
                target="_blank"
                rel="noreferrer"
                className="flex-1 bg-orange-600 hover:bg-orange-700 text-white font-semibold text-xs py-3 px-4 rounded text-center flex items-center justify-center gap-2 transition-colors cursor-pointer"
              >
                <Navigation className="w-4 h-4" />
                <span>Get Directions</span>
                <ExternalLink className="w-3 h-3 opacity-70" />
              </a>

              <a
                href={`tel:${contact.phone.replace(/[^0-9+]/g, '')}`}
                className="flex-1 bg-slate-800 hover:bg-slate-700 text-white font-semibold text-xs py-3 px-4 rounded text-center flex items-center justify-center gap-2 transition-colors cursor-pointer"
              >
                <Phone className="w-4 h-4 text-orange-400" />
                <span>Call Scale Master</span>
              </a>
            </div>
          </div>

          {/* Interactive Simulated Map / Visualizer */}
          <div className="lg:col-span-7 bg-slate-950 rounded-xl border border-slate-800 overflow-hidden relative min-h-[420px] flex flex-col shadow-2xl">
            {/* Map Top Bar */}
            <div className="p-3 bg-slate-900 border-b border-slate-800 flex items-center justify-between text-xs text-slate-300">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-emerald-500" />
                <span className="font-semibold text-white">FerroMax Scrap Terminal 4</span>
                <span className="text-slate-500">·</span>
                <span>Detroit Industrial Corridor</span>
              </div>
              <span className="text-orange-400 font-semibold">Scale Lane Open</span>
            </div>

            {/* Stylized Industrial Blueprint Map Graphic */}
            <div className="relative flex-1 bg-[#071021] overflow-hidden flex items-center justify-center p-6">
              {/* Grid backdrop */}
              <div
                className="absolute inset-0 opacity-15"
                style={{
                  backgroundImage: `radial-gradient(#f05a22 1px, transparent 1px), radial-gradient(#38bdf8 1px, transparent 1px)`,
                  backgroundSize: '24px 24px',
                  backgroundPosition: '0 0, 12px 12px',
                }}
              />

              {/* Highway lines simulation */}
              <div className="absolute inset-x-0 h-10 bg-slate-800/40 rotate-12 -top-5" />
              <div className="absolute inset-y-0 w-12 bg-slate-800/40 -rotate-12 right-20" />

              {/* Yard Perimeter Box */}
              <div className="relative z-10 w-full max-w-lg bg-slate-900/90 backdrop-blur-md rounded-xl border border-slate-700/80 p-6 shadow-2xl space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="w-9 h-9 rounded bg-orange-600 flex items-center justify-center text-white font-bold">
                      <Truck className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-white">4820 Industrial Pkwy Yard</h4>
                      <p className="text-[11px] text-slate-400">Certified Inbound & Outbound Scale Lanes</p>
                    </div>
                  </div>
                  <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-[10px] font-bold">
                    NTEP #24-081
                  </span>
                </div>

                {/* Yard Zones */}
                <div className="grid grid-cols-2 gap-3 text-xs">
                  <div className="p-3 bg-slate-950/60 rounded border border-slate-800">
                    <span className="text-orange-400 font-bold block mb-1">Zone A: Non-Ferrous Drive-Thru</span>
                    <p className="text-[11px] text-slate-400">Copper, Brass, Aluminum, Lead, Catalytic Converters</p>
                  </div>
                  <div className="p-3 bg-slate-950/60 rounded border border-slate-800">
                    <span className="text-orange-400 font-bold block mb-1">Zone B: Heavy Melt & Ferrous</span>
                    <p className="text-[11px] text-slate-400">Structural Steel, Rebar, Machinery, Auto Bodies</p>
                  </div>
                </div>

                {/* Driver Alert */}
                <div className="p-3 rounded bg-orange-950/40 border border-orange-500/30 text-xs text-orange-200 flex items-center justify-between">
                  <span>Driver Notice: Hard hats and high-vis vests required inside scale perimeter.</span>
                  <button
                    onClick={onRequestDropoff}
                    className="shrink-0 bg-orange-600 hover:bg-orange-700 text-white font-bold text-[11px] px-3 py-1.5 rounded cursor-pointer transition-colors"
                  >
                    Book Drop-Off
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
