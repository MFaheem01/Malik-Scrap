import React, { useState } from 'react';
import { Search, X, ArrowRight, Hammer, Zap, Truck, BookOpen, DollarSign } from 'lucide-react';
import { ServiceItem, BlogPost, ScrapPrice } from '../types';

interface QuickSearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  services: ServiceItem[];
  blogs: BlogPost[];
  prices: ScrapPrice[];
  onSelectService: (service: ServiceItem) => void;
  onSelectPrice: (metal: string) => void;
}

export const QuickSearchModal: React.FC<QuickSearchModalProps> = ({
  isOpen,
  onClose,
  services,
  blogs,
  prices,
  onSelectService,
  onSelectPrice,
}) => {
  const [query, setQuery] = useState('');

  if (!isOpen) return null;

  const q = query.toLowerCase().trim();

  const matchedServices = q
    ? services.filter(
        (s) =>
          s.title.toLowerCase().includes(q) ||
          s.shortDesc.toLowerCase().includes(q) ||
          s.category.toLowerCase().includes(q)
      )
    : services.slice(0, 3);

  const matchedPrices = q
    ? prices.filter((p) => p.metal.toLowerCase().includes(q))
    : prices.slice(0, 4);

  const matchedBlogs = q
    ? blogs.filter((b) => b.title.toLowerCase().includes(q) || b.excerpt.toLowerCase().includes(q))
    : [];

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-20 p-4 bg-black/70 backdrop-blur-sm animate-fade-in">
      <div className="bg-white rounded-xl shadow-2xl max-w-2xl w-full border border-slate-200 overflow-hidden">
        {/* Search Input Bar */}
        <div className="p-4 border-b border-slate-200 flex items-center gap-3">
          <Search className="w-5 h-5 text-orange-600" />
          <input
            type="text"
            placeholder="Search metals (copper, brass, steel), roll-off bins, demolition, rates..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            autoFocus
            className="w-full text-base font-medium text-slate-800 placeholder:text-slate-400 focus:outline-none"
          />
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer"
            aria-label="Close search"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Results Area */}
        <div className="max-h-[60vh] overflow-y-auto p-4 space-y-6">
          {/* Scrap Metal Prices matches */}
          <div>
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
              <DollarSign className="w-3.5 h-3.5 text-orange-500" />
              <span>Scrap Metal Price Tickers</span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {matchedPrices.map((item) => (
                <button
                  key={item.metal}
                  onClick={() => {
                    onSelectPrice(item.metal);
                    onClose();
                  }}
                  className="p-2.5 rounded-lg border border-slate-100 hover:border-orange-300 hover:bg-orange-50/50 flex items-center justify-between text-left transition-colors cursor-pointer"
                >
                  <span className="text-xs font-semibold text-slate-800">{item.metal}</span>
                  <span className="text-xs font-bold text-orange-600 tabular-nums">
                    {item.price} <span className="text-[10px] text-slate-400 font-normal">{item.unit}</span>
                  </span>
                </button>
              ))}
            </div>
          </div>

          {/* Services matches */}
          <div>
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
              <Truck className="w-3.5 h-3.5 text-orange-500" />
              <span>Scrap Services & Logistics</span>
            </div>
            <div className="space-y-2">
              {matchedServices.map((service) => (
                <button
                  key={service.id}
                  onClick={() => {
                    onSelectService(service);
                    onClose();
                  }}
                  className="w-full p-3 rounded-lg border border-slate-100 hover:border-orange-300 hover:bg-orange-50/50 flex items-center justify-between text-left transition-colors cursor-pointer group"
                >
                  <div>
                    <h5 className="text-xs font-bold text-slate-900 group-hover:text-orange-600">
                      {service.title}
                    </h5>
                    <p className="text-[11px] text-slate-500 line-clamp-1">{service.shortDesc}</p>
                  </div>
                  <ArrowRight className="w-4 h-4 text-slate-300 group-hover:text-orange-600 group-hover:translate-x-1 transition-all shrink-0 ml-2" />
                </button>
              ))}
            </div>
          </div>

          {/* Blog posts matches */}
          {matchedBlogs.length > 0 && (
            <div>
              <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
                <BookOpen className="w-3.5 h-3.5 text-orange-500" />
                <span>Industry Articles</span>
              </div>
              <div className="space-y-2">
                {matchedBlogs.map((b) => (
                  <div
                    key={b.id}
                    className="p-2.5 rounded-lg border border-slate-100 text-xs text-slate-800 hover:bg-slate-50"
                  >
                    <span className="font-semibold block">{b.title}</span>
                    <span className="text-[11px] text-slate-500">{b.excerpt.substring(0, 80)}...</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Footer info */}
        <div className="p-3 bg-slate-50 border-t border-slate-200 text-center text-xs text-slate-500">
          Press <kbd className="px-1.5 py-0.5 bg-white border border-slate-300 rounded text-[10px]">Esc</kbd> to close
        </div>
      </div>
    </div>
  );
};
